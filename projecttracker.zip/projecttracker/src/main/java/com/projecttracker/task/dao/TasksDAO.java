package com.projecttracker.task.dao;


import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.projecttracker.model.AssignTasks;

@Repository
public interface TasksDAO extends CrudRepository<AssignTasks, Integer>{
       public List<AssignTasks> findByuserId(int userId);
}

