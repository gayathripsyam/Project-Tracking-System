package com.projecttracker.task.dao;


import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.projecttracker.model.AssignTasks;
import com.projecttracker.model.User;

@Repository
public interface UserDAO extends CrudRepository<User, Integer>{
       
}

