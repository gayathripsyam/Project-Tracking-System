package com.projecttracker.task.service;

import java.util.List;


import com.projecttracker.model.AssignTasks;
import com.projecttracker.model.User;

public interface AssignTasksService {
         public void addTasks(AssignTasks tasks);
         public void completedTasks(int usertaskId);
         public List<AssignTasks> listTasks(int userId); 
         public boolean authenticate(User user);
         public boolean checkLeaderStatus(User user);
         public User userInfoById(int userId);
}
